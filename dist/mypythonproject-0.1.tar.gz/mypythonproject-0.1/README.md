#mypythonproject
This library was created for a project of how to publish our own Python package into GitHub at EDSA.

## building this package locally
'python setup.py sdist'

## installing this package from github
'pip install git+https://github.com/MRT678GP/mypythonproject.git'

## updating this package from github
'pip install --upgrade git+https://github.com/MRT678GP/mypythonproject.git'
